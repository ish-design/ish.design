mapboxgl.accessToken = 'pk.eyJ1IjoiaXNoaGgiLCJhIjoiY2pja28wZHllMWhqbzJ3bnMyNHBvODFwMSJ9.mluGh0nCK4-HYyxjL1Ex0g';

var map = new mapboxgl.Map({
  container: 'map', // container element id
  style: 'mapbox://styles/ishhh/cjkionmy83t3s2splvc27cqcw',
  center: [-74.0059, 40.7128], // initial map center in [lon, lat]
  zoom: 11
});

map.on('load', function() {
    map.addLayer({
      id: 'visits',
      type: 'circle',
      source: {
        type: 'geojson',
        data: './primeday.geojson' // replace this with the url of your own geojson
      },
      paint: {
        'circle-color': [
              'interpolate',
              ['exponential', 1],
              ['number', ['get', 'chainname']],
              1, 'hsla(177, 84%, 49%, 1)',
              2, 'hsla(44, 84%, 50%, 1)',
              3, 'hsla(44, 94%, 73%, 1)',
              4, 'hsla(44, 84%, 40%, 1)',
              5, 'hsla(44, 94%, 63%, 1)'
            ],
        'circle-radius': [
          'interpolate',
          ['linear'],
          ['get', 'norm_visits'],
          0, 3,
          90632.7357645053, 100
        ],
        'circle-opacity': 0.8,
      },
      'filter': ['==', ['number',['get', 'local_date']], 71118]
    }, 'admin-2-boundaries-dispute');

    document.getElementById('slider').addEventListener('input', function(e) {
      var date = parseInt(e.target.value);
      // update the map
      map.setFilter('visits', ['==', ['to-number', ['get', 'local_date']], date]);


      // update text in the UI
      document.getElementById('active-date').innerText = date;
    });


  });