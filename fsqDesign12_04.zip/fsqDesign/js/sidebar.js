
		$(function() {
      $('ul.sideBarNav li > ul').hide();
      $('ul.sideBarNav li').click(function(e){
        e.stopPropagation();
        $(this).children('ul').slideToggle();
      });
      $('ul.sideBarNav a').click(function(e){
        //e.stopPropagation();
      });
    });

		$(document).ready(function(){
		    $('#guidelines').click(function(){
		        $('.navIcon').toggleClass('orientation');
		    });
		});