function openOrg(evt, OrgName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(OrgName).style.display = "flex";
    evt.currentTarget.className += " active";
}

document.getElementById("defaultOpen").click();

function openOrgColor(evt, OrgName) {
    var i, tabcontentColor, tablinksColor;
    tabcontentColor = document.getElementsByClassName("tabcontentColor");
    for (i = 0; i < tabcontentColor.length; i++) {
        tabcontentColor[i].style.display = "none";
    }
    tablinksColor = document.getElementsByClassName("tablinksColor");
    for (i = 0; i < tablinksColor.length; i++) {
        tablinksColor[i].className = tablinksColor[i].className.replace(" active", "");
    }
    document.getElementById(OrgName).style.display = "flex";
    evt.currentTarget.className += " active";
}

document.getElementById("defaultOpenColor").click();